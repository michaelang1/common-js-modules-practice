const helloMessage = 'Greetings! Let us begin!';

// Option A
module.exports = {
	helloMessage,
};

// Option B
// module.exports.helloMessage = helloMessage;

//Option C
// exports.helloMessage = helloMessage;

// exporting one item;
// module.exports = helloMessage;
